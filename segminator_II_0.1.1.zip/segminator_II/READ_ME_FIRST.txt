Once you have navigated to the correct directory using a terminal window this program should be launched using the command:

java -jar -Xmx2000M segminator_II_v0.1.1.jar

If on Windows the windows.bat file may be used. Double clicking on the .jar file directly will not allocate enough memory to process larger datasets.

Additionally the more cores available on the machine used for processing the smoother/faster the program will run. By default Segminator II uses the (total number of cores - 1) but this can be changed within the parameters menu.